# Data lineage resumido
- `dim_fecha.fecha`: `Base De Datos.Fecha`, convertida a DATE; filas con fecha inválida no cargan a hechos.
- `dim_maquina.maquina_nk`: `Base De Datos.Maquina`, trim y normalización de vacío.
- `dim_turno.turno_nk`: `Base De Datos.Turno`, vacío sustituido por `NO_INFORMADO`.
- `dim_referencia.referencia_nk`: `Base De Datos.Referencia`, vacío sustituido por `NO_INFORMADO`.
- `fact_produccion.pacas_producidas`: `Base De Datos.Pacas producidas`, conversión numérica, faltantes conservados como NULL.
- `fact_produccion.horas_trabajadas`: `Base De Datos.Horas trabajadas`, conversión numérica, faltantes conservados como NULL.
- `fact_produccion.horas_no_trabajadas`: `Base De Datos.Horas no trabajadas`, conversión numérica.
- `fact_produccion.operario_token`: hash SHA-256 truncado del nombre de operario; seudonimización básica, no anonimización irreversible garantizada si el conjunto de nombres es pequeño.
- `fact_paros`: fuente prevista en las columnas `Codigo de paro N`, `Codigo N en horas` y campos de subcódigo. Completar el mapeo de todas las ranuras antes de la entrega final.
