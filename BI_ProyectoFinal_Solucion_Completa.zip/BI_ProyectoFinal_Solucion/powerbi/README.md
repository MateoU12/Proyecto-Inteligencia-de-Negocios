# Power BI
Conectar Power BI Desktop a PostgreSQL (host localhost, puerto 5432, base bi_produccion). Importar dimensiones y hechos desde el esquema `bi`. Crear relaciones 1:* desde dimensiones a hechos y marcar `dim_fecha[fecha]` como tabla de fechas. Usar `medidas_dax.txt` como base y ajustar los nombres si el conector los cambia.

El archivo `.pbix` es binario y difícil de revisar en Git. Para la entrega final, guardar como proyecto `.pbip` desde Power BI Desktop (Archivo > Guardar como > Proyecto de Power BI) y versionar los archivos de texto del proyecto. Este paquete no simula una exportación real de Power BI: incluye diseño de referencia y medidas iniciales; el informe debe abrirse y guardarse desde Power BI Desktop.
