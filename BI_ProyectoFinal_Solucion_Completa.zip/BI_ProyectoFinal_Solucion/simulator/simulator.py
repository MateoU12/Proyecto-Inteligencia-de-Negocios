import os, time, random
from datetime import datetime, timezone
import psycopg2

URL=os.getenv("PGHOST","localhost")
while True:
    try:
        conn=psycopg2.connect(host=URL,port=os.getenv("PGPORT","5432"),dbname=os.getenv("POSTGRES_DB","bi_produccion"),
          user=os.getenv("POSTGRES_USER","bi_user"),password=os.getenv("POSTGRES_PASSWORD","change_me"))
        break
    except Exception as e:
        print("Esperando PostgreSQL...",e); time.sleep(5)
cur=conn.cursor()
cur.execute("""CREATE TABLE IF NOT EXISTS bi.simulacion_operativa(
 id BIGSERIAL PRIMARY KEY, timestamp_evento TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 maquina VARCHAR(80) NOT NULL, turno VARCHAR(80), produccion_pacas NUMERIC(12,2),
 paro_minutos NUMERIC(12,2), estado VARCHAR(30) NOT NULL)""")
conn.commit()
while True:
    machine=random.choice(["Vinilos_1","Vinilos_2","Vinilos_3","Vinilos_4"])
    downtime=random.choice([0,0,0,5,10,20,35])
    output=random.randint(4,14) if downtime<20 else random.randint(0,5)
    state="ALERTA" if downtime>=20 else ("PARO" if downtime>0 else "PRODUCIENDO")
    cur.execute("""INSERT INTO bi.simulacion_operativa(maquina,turno,produccion_pacas,paro_minutos,estado)
    VALUES(%s,%s,%s,%s,%s)""",(machine,"SIMULADO",output,downtime,state))
    conn.commit()
    print(datetime.now(),machine,output,downtime,state)
    time.sleep(int(os.getenv("SIM_INTERVAL_SECONDS","3600")))
