CREATE SCHEMA IF NOT EXISTS bi;

CREATE TABLE IF NOT EXISTS bi.dim_fecha (
  fecha_key INTEGER PRIMARY KEY, fecha DATE NOT NULL UNIQUE,
  dia SMALLINT NOT NULL, mes SMALLINT NOT NULL, nombre_mes VARCHAR(15) NOT NULL,
  trimestre SMALLINT NOT NULL, anio SMALLINT NOT NULL, dia_semana SMALLINT NOT NULL,
  nombre_dia VARCHAR(15) NOT NULL, es_fin_semana BOOLEAN NOT NULL
);

CREATE TABLE IF NOT EXISTS bi.dim_maquina (
  maquina_key BIGSERIAL PRIMARY KEY, maquina_nk VARCHAR(80) NOT NULL UNIQUE,
  maquina_nombre VARCHAR(120) NOT NULL, activa BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS bi.dim_turno (
  turno_key BIGSERIAL PRIMARY KEY, turno_nk VARCHAR(100) NOT NULL UNIQUE,
  turno_nombre VARCHAR(100) NOT NULL
);

CREATE TABLE IF NOT EXISTS bi.dim_referencia (
  referencia_key BIGSERIAL PRIMARY KEY, referencia_nk VARCHAR(200) NOT NULL UNIQUE,
  referencia_nombre VARCHAR(200) NOT NULL
);

CREATE TABLE IF NOT EXISTS bi.dim_paro (
  paro_key BIGSERIAL PRIMARY KEY, codigo_nk VARCHAR(30) NOT NULL,
  codigo_nombre VARCHAR(250) NOT NULL, subcodigo_nk VARCHAR(80) NOT NULL DEFAULT 'NO_INFORMADO',
  subcodigo_nombre VARCHAR(250) NOT NULL DEFAULT 'No informado',
  area_involucrada VARCHAR(120), personal_involucrado VARCHAR(120),
  UNIQUE(codigo_nk, subcodigo_nk)
);

-- Grain: one row per source production register (source row id retained).
CREATE TABLE IF NOT EXISTS bi.fact_produccion (
  produccion_key BIGSERIAL PRIMARY KEY, source_row_id BIGINT NOT NULL UNIQUE,
  fecha_key INTEGER REFERENCES bi.dim_fecha(fecha_key),
  maquina_key BIGINT REFERENCES bi.dim_maquina(maquina_key),
  turno_key BIGINT REFERENCES bi.dim_turno(turno_key),
  referencia_key BIGINT REFERENCES bi.dim_referencia(referencia_key),
  pacas_producidas NUMERIC(14,3), horas_trabajadas NUMERIC(12,3),
  horas_no_trabajadas NUMERIC(12,3), meta_por_hora NUMERIC(12,3),
  operario_token VARCHAR(80), observaciones TEXT,
  fecha_carga TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Grain: one row per source register and one recorded downtime-code slot.
CREATE TABLE IF NOT EXISTS bi.fact_paros (
  paro_hecho_key BIGSERIAL PRIMARY KEY, source_row_id BIGINT NOT NULL,
  slot_codigo SMALLINT NOT NULL,
  fecha_key INTEGER REFERENCES bi.dim_fecha(fecha_key),
  maquina_key BIGINT REFERENCES bi.dim_maquina(maquina_key),
  turno_key BIGINT REFERENCES bi.dim_turno(turno_key),
  paro_key BIGINT REFERENCES bi.dim_paro(paro_key),
  duracion_horas NUMERIC(12,4),
  observaciones TEXT,
  fecha_carga TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(source_row_id, slot_codigo)
);

CREATE INDEX IF NOT EXISTS ix_fact_prod_fecha_maquina ON bi.fact_produccion(fecha_key, maquina_key);
CREATE INDEX IF NOT EXISTS ix_fact_prod_turno ON bi.fact_produccion(turno_key);
CREATE INDEX IF NOT EXISTS ix_fact_paros_fecha_maquina ON bi.fact_paros(fecha_key, maquina_key);
CREATE INDEX IF NOT EXISTS ix_fact_paros_paro ON bi.fact_paros(paro_key);
CREATE INDEX IF NOT EXISTS ix_dim_paro_codigo ON bi.dim_paro(codigo_nk, subcodigo_nk);
