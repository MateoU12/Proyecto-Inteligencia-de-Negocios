-- Q1. Producción por máquina y año
SELECT f.anio, m.maquina_nombre, SUM(p.pacas_producidas) AS pacas
FROM bi.fact_produccion p JOIN bi.dim_fecha f USING(fecha_key)
JOIN bi.dim_maquina m USING(maquina_key)
GROUP BY f.anio, m.maquina_nombre ORDER BY f.anio, pacas DESC;

-- Q2. Top de causas por horas de paro
SELECT d.codigo_nk, d.codigo_nombre, d.subcodigo_nombre,
       SUM(p.duracion_horas) AS horas_paro,
       RANK() OVER (ORDER BY SUM(p.duracion_horas) DESC) AS ranking
FROM bi.fact_paros p JOIN bi.dim_paro d USING(paro_key)
GROUP BY d.codigo_nk,d.codigo_nombre,d.subcodigo_nombre
ORDER BY horas_paro DESC;

-- Q3. Variación de producción frente al año anterior (LAG)
WITH anual AS (
 SELECT f.anio, m.maquina_nombre, SUM(p.pacas_producidas) AS pacas
 FROM bi.fact_produccion p JOIN bi.dim_fecha f USING(fecha_key)
 JOIN bi.dim_maquina m USING(maquina_key)
 GROUP BY f.anio,m.maquina_nombre
)
SELECT *, LAG(pacas) OVER(PARTITION BY maquina_nombre ORDER BY anio) AS pacas_anio_anterior,
       pacas - LAG(pacas) OVER(PARTITION BY maquina_nombre ORDER BY anio) AS variacion_absoluta
FROM anual ORDER BY maquina_nombre, anio;

-- Q4. Producción mensual
SELECT f.anio, f.mes, f.nombre_mes, m.maquina_nombre,
       SUM(p.pacas_producidas) AS pacas
FROM bi.fact_produccion p JOIN bi.dim_fecha f USING(fecha_key)
JOIN bi.dim_maquina m USING(maquina_key)
GROUP BY f.anio,f.mes,f.nombre_mes,m.maquina_nombre
ORDER BY f.anio,f.mes,m.maquina_nombre;

-- Q5. Control de duplicados en hechos de producción
SELECT source_row_id, COUNT(*) AS filas
FROM bi.fact_produccion GROUP BY source_row_id HAVING COUNT(*) > 1;
