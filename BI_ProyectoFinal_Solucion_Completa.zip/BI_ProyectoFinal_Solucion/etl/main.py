"""
ETL reproducible para SEGUIMIENTO TEMPERAS Y VINILOS.
Uso: python etl/main.py --input "SEGUIMIENTO TEMPERAS Y VINILOS Actividad.xlsm"
Requiere DATABASE_URL, por ejemplo postgresql+psycopg2://bi_user:CAMBIAR@localhost:5432/bi_produccion
No calcula OEE si los insumos necesarios no están validados.
"""
import argparse, os, re, hashlib
import pandas as pd
from sqlalchemy import create_engine, text

def load_source(path, sheet="Base De Datos"):
    raw = pd.read_excel(path, sheet_name=sheet, header=None, engine="openpyxl")
    header_idx = None
    for i, row in raw.iterrows():
        if any(str(v).strip() == "Fecha" for v in row.tolist() if pd.notna(v)):
            header_idx = i; break
    if header_idx is None: raise ValueError("No se encontró encabezado Fecha")
    cols = raw.iloc[header_idx].tolist()
    df = raw.iloc[header_idx+1:].copy(); df.columns = cols
    df = df.dropna(how="all")
    df = df.loc[:, [c for c in df.columns if c is not None and str(c).strip() not in ("", "nan")]]
    clean=[]; seen={}
    for c in df.columns:
        n=str(c).replace("\\n"," ").strip()
        seen[n]=seen.get(n,0)+1
        clean.append(n if seen[n]==1 else f"{n}_{seen[n]}")
    df.columns=clean
    df["source_row_id"] = range(1, len(df)+1)
    return df

def normalize(df):
    report={}
    report["rows_source"]=len(df)
    for col in ["Fecha"]:
        df[col]=pd.to_datetime(df[col],errors="coerce")
    numeric=["Pacas producidas","Horas trabajadas","Horas no trabajadas","Tiempo de Paro","Meta por hora"]
    for c in numeric:
        if c in df: df[c]=pd.to_numeric(df[c],errors="coerce")
    for c in ["Maquina","Turno","Referencia","Tipo de paro","Observaciones","Observaciones de paro"]:
        if c in df:
            df[c]=df[c].astype("string").str.strip()
            df[c]=df[c].replace({"":pd.NA,"nan":pd.NA,"None":pd.NA})
    report["invalid_dates"]=int(df["Fecha"].isna().sum())
    report["missing_machine"]=int(df["Maquina"].isna().sum())
    report["negative_pacas"]=int((df.get("Pacas producidas",pd.Series(dtype=float))<0).sum())
    report["negative_downtime"]=int((df.get("Tiempo de Paro",pd.Series(dtype=float))<0).sum())
    # Don't convert missing numeric values to zero; preserve missingness.
    # Reject records without machine/date from facts, but keep counts in report.
    df["fecha_valida"]=df["Fecha"].notna()
    df["maquina_valida"]=df["Maquina"].notna()
    return df, report

def token_persona(value):
    if pd.isna(value) or not str(value).strip(): return None
    return hashlib.sha256(str(value).strip().lower().encode()).hexdigest()[:16]

def load_postgres(df, report, url):
    engine=create_engine(url)
    with engine.begin() as conn:
        conn.execute(text("CREATE SCHEMA IF NOT EXISTS bi"))
        # Read DDL file in project root's sql folder
        ddl_path=os.path.join(os.path.dirname(__file__),"..","sql","01_modelo_dimensional.sql")
        with open(ddl_path,encoding="utf-8") as f:
            for stmt in f.read().split(";"):
                if stmt.strip(): conn.execute(text(stmt))
        valid=df[df["fecha_valida"] & df["maquina_valida"]].copy()
        # Load date dimension
        dates=pd.to_datetime(valid["Fecha"].dropna().unique())
        for dt in dates:
            d=pd.Timestamp(dt)
            conn.execute(text("""INSERT INTO bi.dim_fecha(fecha_key,fecha,dia,mes,nombre_mes,trimestre,anio,dia_semana,nombre_dia,es_fin_semana)
            VALUES(:k,:f,:dia,:mes,:nm,:t,:a,:dw,:nd,:we) ON CONFLICT(fecha) DO NOTHING"""),
            {"k":int(d.strftime("%Y%m%d")),"f":d.date(),"dia":d.day,"mes":d.month,"nm":d.strftime("%B"),
             "t":(d.month-1)//3+1,"a":d.year,"dw":d.weekday()+1,"nd":d.strftime("%A"),"we":d.weekday()>=5})
        for col,table,nk,namecol in [("Maquina","dim_maquina","maquina_nk","maquina_nombre"),
                                     ("Turno","dim_turno","turno_nk","turno_nombre"),
                                     ("Referencia","dim_referencia","referencia_nk","referencia_nombre")]:
            vals=valid[col].fillna("NO_INFORMADO").astype(str).str.strip().unique() if col in valid else ["NO_INFORMADO"]
            for val in vals:
                conn.execute(text(f"INSERT INTO bi.{table}({nk},{namecol}) VALUES(:v,:v) ON CONFLICT({nk}) DO NOTHING"),{"v":val})
        # Source fields are loaded row-wise to make lineage clear.
        for _,r in valid.iterrows():
            date_key=int(pd.Timestamp(r["Fecha"]).strftime("%Y%m%d"))
            machine=str(r["Maquina"]).strip()
            turn=str(r.get("Turno") if pd.notna(r.get("Turno")) else "NO_INFORMADO").strip()
            ref=str(r.get("Referencia") if pd.notna(r.get("Referencia")) else "NO_INFORMADO").strip()
            keys=conn.execute(text("""SELECT (SELECT maquina_key FROM bi.dim_maquina WHERE maquina_nk=:m),
            (SELECT turno_key FROM bi.dim_turno WHERE turno_nk=:t),
            (SELECT referencia_key FROM bi.dim_referencia WHERE referencia_nk=:r)"""),{"m":machine,"t":turn,"r":ref}).one()
            conn.execute(text("""INSERT INTO bi.fact_produccion
            (source_row_id,fecha_key,maquina_key,turno_key,referencia_key,pacas_producidas,horas_trabajadas,horas_no_trabajadas,meta_por_hora,operario_token,observaciones)
            VALUES(:id,:fk,:mk,:tk,:rk,:p,:h,:hn,:meta,:op,:obs)
            ON CONFLICT(source_row_id) DO UPDATE SET pacas_producidas=EXCLUDED.pacas_producidas,
            horas_trabajadas=EXCLUDED.horas_trabajadas, horas_no_trabajadas=EXCLUDED.horas_no_trabajadas"""),
            {"id":int(r["source_row_id"]),"fk":date_key,"mk":keys[0],"tk":keys[1],"rk":keys[2],
             "p":r.get("Pacas producidas"),"h":r.get("Horas trabajadas"),"hn":r.get("Horas no trabajadas"),
             "meta":r.get("Meta por hora"),"op":token_persona(r.get("Operario")),"obs":str(r.get("Observaciones") or "")[:2000]})
        # Load every positive recorded downtime slot. Column "Codigo N en horas" stores
        # duration in hours; slot N identifies the code number. Subcode columns are
        # optional and differ in spelling in the workbook.
        code_names = {
          1:"Falla del sistema electromecánico y/o de control",
          2:"Espera de soporte de mantenimiento",
          3:"Novedad en los sistemas de potencia (aire, energía, vapor)",
          4:"Mantenimiento preventivo", 5:"Ajuste operativo",
          6:"Limpieza por derrame operativo", 7:"Alistamiento de máquina / Cambio de referencia",
          8:"Capacitación / Reunión", 9:"Falta de operario",
          10:"Paro por ventaja / evacuación", 11:"Reproceso",
          12:"Materia prima defectuosa", 13:"En espera por aval del laboratorio",
          14:"Falta de materia prima", 15:"Cambio de insumos",
          16:"Alimentación y aseo de zona/máquina", 17:"Pausa activa",
          18:"Código 18: validar descripción en catálogo"
        }
        subcode_cols = {
          1:"Sub Codigo de paro 1", 3:"Subcodigo 3", 5:"Subcodigo 5"
        }
        loaded_downtime_rows = 0
        for _, r in valid.iterrows():
            date_key=int(pd.Timestamp(r["Fecha"]).strftime("%Y%m%d"))
            machine=str(r["Maquina"]).strip()
            turn=str(r.get("Turno") if pd.notna(r.get("Turno")) else "NO_INFORMADO").strip()
            keys=conn.execute(text("""SELECT (SELECT maquina_key FROM bi.dim_maquina WHERE maquina_nk=:m),
                (SELECT turno_key FROM bi.dim_turno WHERE turno_nk=:t)"""),{"m":machine,"t":turn}).one()
            for slot in range(1,19):
                dur_col=f"Codigo {slot} en horas"
                if dur_col not in valid.columns: continue
                duration=pd.to_numeric(pd.Series([r.get(dur_col)]),errors="coerce").iloc[0]
                if pd.isna(duration) or float(duration) <= 0: continue
                sub_col=subcode_cols.get(slot)
                subvalue=r.get(sub_col) if sub_col and sub_col in valid.columns else None
                subvalue=str(subvalue).strip() if pd.notna(subvalue) and str(subvalue).strip() else "No informado"
                code=str(slot).zfill(2)
                code_name=code_names.get(slot, f"Código {code}")
                conn.execute(text("""INSERT INTO bi.dim_paro
                    (codigo_nk,codigo_nombre,subcodigo_nk,subcodigo_nombre)
                    VALUES(:c,:cn,:sc,:sn)
                    ON CONFLICT(codigo_nk,subcodigo_nk) DO NOTHING"""),
                    {"c":code,"cn":code_name,"sc":subvalue.upper()[:80],"sn":subvalue[:250]})
                paro_key=conn.execute(text("""SELECT paro_key FROM bi.dim_paro
                    WHERE codigo_nk=:c AND subcodigo_nk=:sc"""),
                    {"c":code,"sc":subvalue.upper()[:80]}).scalar_one()
                conn.execute(text("""INSERT INTO bi.fact_paros
                    (source_row_id,slot_codigo,fecha_key,maquina_key,turno_key,paro_key,duracion_horas,observaciones)
                    VALUES(:id,:slot,:fk,:mk,:tk,:pk,:dur,:obs)
                    ON CONFLICT(source_row_id,slot_codigo) DO UPDATE SET
                    duracion_horas=EXCLUDED.duracion_horas, paro_key=EXCLUDED.paro_key"""),
                    {"id":int(r["source_row_id"]),"slot":slot,"fk":date_key,"mk":keys[0],"tk":keys[1],
                     "pk":paro_key,"dur":float(duration),"obs":str(r.get("Observaciones de paro") or "")[:2000]})
                loaded_downtime_rows += 1
        report["rows_eligible"]=len(valid)
        report["rows_rejected_missing_date_or_machine"]=len(df)-len(valid)
        report["production_sum_loaded"]=float(valid.get("Pacas producidas",pd.Series(dtype=float)).sum(skipna=True))
        report["hours_sum_loaded"]=float(valid.get("Horas trabajadas",pd.Series(dtype=float)).sum(skipna=True))
        report["downtime_slots_loaded"]=loaded_downtime_rows
        report["downtime_hours_loaded"]=float(pd.to_numeric(
            pd.Series([r.get(f"Codigo {slot} en horas") for _,r in valid.iterrows() for slot in range(1,19)]),
            errors="coerce").fillna(0).clip(lower=0).sum())
    print("ETL finalizado. Resumen:",report)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--input",required=True); ap.add_argument("--sheet",default="Base De Datos")
    args=ap.parse_args()
    df=load_source(args.input,args.sheet); df,report=normalize(df)
    print("Control de calidad:",report)
    url=os.environ.get("DATABASE_URL")
    if not url: raise EnvironmentError("Define DATABASE_URL en variables de entorno.")
    load_postgres(df,report,url)

if __name__=="__main__": main()
