# Proyecto BI de producción: Vinilos y témperas

## Objetivo
Integrar el registro histórico de producción y paros en un modelo dimensional PostgreSQL, validar la calidad de los datos y habilitar análisis histórico en Power BI y monitoreo operativo demostrativo en Grafana.

## Fuente y diagnóstico inicial
Archivo: `SEGUIMIENTO TEMPERAS Y VINILOS Actividad.xlsm`, hoja `Base De Datos`. Se detectó encabezado en la fila 9 de Excel. La hoja contiene 8,208 filas con datos entre 2022-01-01 y 2025-03-28. Hay 4 máquinas distintas. La suma de `Pacas producidas` en valores disponibles es 378,778; es un total de valores no vacíos, no representa necesariamente producción completa porque el campo tiene faltantes.

## Hallazgos de calidad (observados)
- Filas fuente: 8,208.
- Fechas no interpretables: 0.
- Filas con máquina identificada: 8,208.
- Registros con pacas no vacías: 5,157.
- Registros con horas trabajadas no vacías: 5,159.
- Operario vacío: 3,721; referencia vacía: 3,874; turno vacío: 3,912.
- No debe calcularse OEE hasta confirmar tiempo planificado, velocidad ideal de la referencia y unidades buenas/rechazadas. No convertir campos vacíos a cero sin regla de negocio.

## Arquitectura
Excel → ETL Python → PostgreSQL (esquema `bi`) → Power BI (histórico) y Grafana (simulación operativa). Docker Compose levanta PostgreSQL, Grafana y un simulador. El ETL histórico se ejecuta manualmente después de iniciar PostgreSQL.

## Requisitos
- Docker Desktop + Docker Compose
- Python 3.10+
- Power BI Desktop (Windows) para generar el proyecto `.pbip`
- DBeaver para administración SQL

## Arranque de servicios
1. Copiar `.env.example` como `.env` y cambiar las contraseñas.
2. Ejecutar `docker compose up -d --build`.
3. Abrir Grafana en `http://localhost:3000` con las credenciales del `.env`.
4. El simulador genera una fila cada `SIM_INTERVAL_SECONDS` (por defecto 3600 s). Para la demostración, se puede cambiar temporalmente a `60` segundos y luego restaurar a `3600`.
5. Conectar DBeaver a `localhost:5432`, base definida en `.env`.

## Cargar datos históricos
1. Crear entorno e instalar `pip install -r etl/requirements.txt`.
2. Definir `DATABASE_URL` en la terminal, con credenciales del `.env`, por ejemplo `postgresql+psycopg2://bi_user:TU_CLAVE@localhost:5432/bi_produccion`.
3. Ejecutar `python etl/main.py --input "SEGUIMIENTO TEMPERAS Y VINILOS Actividad.xlsm"`.
4. Revisar el resumen de validación en consola y comparar sumas con el origen.

## Modelo
- `dim_fecha`: calendario propio con jerarquía año > trimestre > mes > día.
- `dim_maquina`, `dim_turno`, `dim_referencia`: atributos descriptivos para filtros.
- `dim_paro`: código y subcódigo en una misma dimensión jerárquica.
- `fact_produccion`: una fila por registro de origen.
- `fact_paros`: una fila por registro y ranura de código de paro. Completar su carga con el detalle de códigos y subcódigos disponible en las columnas de la fuente; ver nota técnica más abajo.

## Nota técnica importante
Este paquete es una base reproducible y documentada, no una afirmación de despliegue ya ejecutado. El ETL carga `fact_produccion` y recorre las 18 columnas `Codigo N en horas` para cargar `fact_paros`. Las ranuras 1, 3 y 5 toman subcódigos de las columnas disponibles; las demás usan `No informado`. Debe revisarse el catálogo de la ranura 18 y compararse la suma de horas cargadas con la fuente antes de cerrar la entrega. El tablero de Grafana usa la tabla `bi.simulacion_operativa`, creada por el simulador. El modelo de Power BI debe guardarse desde Power BI Desktop. Las imágenes del PDF son gráficas derivadas de la fuente y maquetas explicativas, no capturas de aplicaciones desplegadas.

## Privacidad y seguridad
- Se almacena un token SHA-256 del nombre de operario en lugar del nombre visible en la tabla de hechos.
- No publicar el Excel original si contiene nombres u otros datos personales sin autorización.
- Restringir acceso a PostgreSQL/Grafana; usar contraseñas robustas; `.env` no se versiona.
- Los tableros para gerencia deben mostrar datos agregados y no nombres personales salvo necesidad autorizada.

## Archivos
- `sql/01_modelo_dimensional.sql`: DDL.
- `sql/02_consultas_analiticas.sql`: consultas con agregaciones y funciones de ventana.
- `etl/main.py`: extracción, normalización y carga inicial de producción.
- `simulator/simulator.py`: datos operativos simulados.
- `grafana/`: provisioning y tablero JSON.
- `powerbi/`: guía y medidas DAX iniciales.
- `docs/`: gráficos de diagnóstico y maqueta visual.
- `informe/`: PDF de informe principal.

## Matriz de bus (resumen)
| Proceso | Fecha | Máquina | Turno | Referencia | Paro |
|---|---|---|---|---|---|
| Producción | X | X | X | X | |
| Paros | X | X | X | | X |
| Monitoreo simulado | timestamp | X | X | | estado/causa simulada |

## Comparación de herramientas
- Power BI: análisis histórico, comparativos entre periodos, segmentación por referencia, máquina y turno; actualización por consulta/actualización del modelo.
- Grafana: vigilancia continua de eventos simulados, paneles de series de tiempo y alertas operativas; no reemplaza el análisis gerencial de Power BI.

## Evolución a PLC/SCADA
Un gateway industrial puede leer variables de PLC/SCADA y publicar eventos por MQTT/OPC UA a una capa de ingesta. La ingesta validaría timestamps, máquina, estado y contadores; luego guardaría en PostgreSQL o un almacén de series temporales. Se requerirían segmentación de red, permisos de solo lectura, monitoreo y pruebas de continuidad.
